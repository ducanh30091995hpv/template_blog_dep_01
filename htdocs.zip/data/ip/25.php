<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:19:59 GMT
 */

$ranges=array(419430400=>array(426470229,'GB'),426470230=>array(426470230,'IT'),426470231=>array(436207615,'GB'));
